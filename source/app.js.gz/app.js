import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.118.0/+esm'

const SUPABASE_URL = 'https://rrulyvkarrwbopqeciyz.supabase.co'
const SUPABASE_KEY = 'sb_publishable_PGO2G81WqwkxOEeQO-CI8A_YjXtUhiU'
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY)

const $ = (s, root = document) => root.querySelector(s)
const $$ = (s, root = document) => [...root.querySelectorAll(s)]
const money = value => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(value || 0))
const esc = value => String(value ?? '').replace(/[&<>'"]/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;' }[c]))
const pct = (a, b) => b ? Math.max(0, Math.min(100, Math.round((Number(a) / Number(b)) * 100))) : 0
const sleep = ms => new Promise(r => setTimeout(r, ms))

let currentUser = null
let profile = null
let offers = []
let favorites = new Set()
let waitlist = new Set()
let orders = []
let business = null
let sellerOffers = []
let activeCategory = 'all'
let pendingJoinId = null
let activeOfferId = null
let currentView = 'home'

function toast(message) {
  const el = $('#toast')
  el.textContent = message
  el.classList.add('show')
  clearTimeout(window.__juntaToast)
  window.__juntaToast = setTimeout(() => el.classList.remove('show'), 3200)
}

function openModal(id) {
  const el = $('#' + id)
  if (!el) return
  el.classList.remove('hidden')
  document.body.style.overflow = 'hidden'
  setTimeout(() => el.querySelector('input,button,select,textarea')?.focus(), 30)
}

function closeModal(id) {
  $('#' + id)?.classList.add('hidden')
  if (!$$('.modal-backdrop:not(.hidden)').length) document.body.style.overflow = ''
}

function dateTime(value) {
  if (!value) return '—'
  return new Intl.DateTimeFormat('pt-BR', { day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit' }).format(new Date(value))
}

function roleLabel(role) {
  return ({ buyer:'Comprador', seller:'Empresa', admin:'Admin' })[role] || 'Comprador'
}

function statusLabel(status) {
  return ({ pending:'Em análise', approved:'Aprovada', suspended:'Suspensa', draft:'Rascunho', scheduled:'Agendada', open:'Aberta', closed:'Encerrada', cancelled:'Cancelada', sold_out:'Esgotada' })[status] || status
}

function offerActionLabel(offer) {
  if (waitlist.has(offer.id)) return '✓ Você está na fila'
  if (offer.status === 'open') return 'Comprar agora'
  if (offer.status === 'sold_out') return 'Esgotado'
  return 'Entrar na fila'
}

async function init() {
  wireStaticEvents()
  renderOfferSkeletons()
  startGlobalCountdown()

  const { data: { session } } = await supabase.auth.getSession()
  currentUser = session?.user || null
  await Promise.all([loadOffers(), loadUserState()])
  renderAll()

  supabase.auth.onAuthStateChange((_event, session) => {
    currentUser = session?.user || null
    queueMicrotask(async () => {
      await Promise.all([loadOffers(), loadUserState()])
      renderAll()
      if (currentUser && pendingJoinId) {
        const id = pendingJoinId
        pendingJoinId = null
        await toggleWaitlist(id, true)
      }
    })
  })
}

function wireStaticEvents() {
  $$('[data-close]').forEach(btn => btn.addEventListener('click', () => closeModal(btn.dataset.close)))
  $$('.modal-backdrop').forEach(backdrop => backdrop.addEventListener('click', e => { if (e.target === backdrop) closeModal(backdrop.id) }))
  document.addEventListener('keydown', e => { if (e.key === 'Escape') $$('.modal-backdrop:not(.hidden)').forEach(m => closeModal(m.id)) })

  $$('[data-scroll]').forEach(btn => btn.addEventListener('click', () => {
    showView('home')
    setTimeout(() => $(btn.dataset.scroll)?.scrollIntoView({ behavior:'smooth', block:'start' }), 40)
  }))
  $$('[data-view]').forEach(btn => btn.addEventListener('click', () => showView(btn.dataset.view)))

  $('#accountBtn').addEventListener('click', () => currentUser ? showView('account') : openModal('authModal'))
  $('#mobileAccount').addEventListener('click', () => currentUser ? showView('account') : openModal('authModal'))
  $('#sellerLoginBtn').addEventListener('click', () => openModal('authModal'))
  $('#openBusinessModal').addEventListener('click', () => openModal('businessModal'))
  $('#newOfferBtn').addEventListener('click', () => { fillOfferDateDefaults(); openModal('newOfferModal') })
  $('#logoutBtn').addEventListener('click', async () => { await supabase.auth.signOut(); showView('home'); toast('Você saiu da conta') })

  $$('.category-chip').forEach(btn => btn.addEventListener('click', () => {
    activeCategory = btn.dataset.category
    $$('.category-chip').forEach(b => b.classList.toggle('active', b === btn))
    renderOffers()
  }))

  $$('[data-auth-tab]').forEach(btn => btn.addEventListener('click', () => {
    $$('[data-auth-tab]').forEach(b => b.classList.toggle('active', b === btn))
    $('#loginForm').classList.toggle('hidden', btn.dataset.authTab !== 'login')
    $('#signupForm').classList.toggle('hidden', btn.dataset.authTab !== 'signup')
  }))

  $$('[data-account-tab]').forEach(btn => btn.addEventListener('click', () => {
    $$('[data-account-tab]').forEach(b => b.classList.toggle('active', b === btn))
    $$('[data-account-panel]').forEach(p => p.classList.toggle('active', p.dataset.accountPanel === btn.dataset.accountTab))
  }))

  $('#loginForm').addEventListener('submit', login)
  $('#signupForm').addEventListener('submit', signup)
  $('#businessForm').addEventListener('submit', createBusiness)
  $('#offerForm').addEventListener('submit', createOffer)
}

function showView(name) {
  if (name === 'account' && !currentUser) return openModal('authModal')
  if (name === 'admin' && profile?.role !== 'admin') return toast('Área restrita ao administrador')
  currentView = name
  $$('.app-view').forEach(view => view.classList.toggle('active', view.dataset.page === name))
  window.scrollTo({ top:0, behavior:'smooth' })
  if (name === 'seller') renderSeller()
  if (name === 'account') renderAccount()
  if (name === 'admin') loadAdmin()
}

async function loadOffers() {
  const { data, error } = await supabase.from('offer_feed').select('*').order('featured', { ascending:false }).order('opens_at', { ascending:true })
  if (error) {
    console.error(error)
    offers = []
    toast('Não foi possível carregar as ofertas')
    return
  }
  offers = data || []
}

async function loadUserState() {
  profile = null
  favorites = new Set()
  waitlist = new Set()
  orders = []
  business = null
  sellerOffers = []
  if (!currentUser) return

  const [profileRes, favRes, waitRes, orderRes, businessRes] = await Promise.all([
    supabase.from('profiles').select('*').eq('user_id', currentUser.id).maybeSingle(),
    supabase.from('favorite_offers').select('offer_id').eq('user_id', currentUser.id),
    supabase.from('offer_waitlist').select('offer_id').eq('user_id', currentUser.id),
    supabase.from('orders').select('*').eq('user_id', currentUser.id).order('created_at', { ascending:false }),
    supabase.from('businesses').select('*').eq('owner_id', currentUser.id).order('created_at', { ascending:true }).limit(1).maybeSingle()
  ])

  profile = profileRes.data || null
  ;(favRes.data || []).forEach(row => favorites.add(row.offer_id))
  ;(waitRes.data || []).forEach(row => waitlist.add(row.offer_id))
  orders = orderRes.data || []
  business = businessRes.data || null

  if (business) {
    const { data } = await supabase.from('offers').select('*').eq('business_id', business.id).order('created_at', { ascending:false })
    sellerOffers = data || []
  }
}

function renderAll() {
  renderAuthState()
  renderOffers()
  renderAccount()
  renderSeller()
}

function renderAuthState() {
  $('#accountLabel').textContent = currentUser ? (profile?.display_name?.split(' ')[0] || 'Minha conta') : 'Entrar'
  const old = $('#adminQuick')
  if (profile?.role === 'admin' && !old) {
    const btn = document.createElement('button')
    btn.id = 'adminQuick'
    btn.className = 'ghost-btn'
    btn.textContent = 'Admin'
    btn.addEventListener('click', () => showView('admin'))
    $('.header-actions').prepend(btn)
  } else if (profile?.role !== 'admin' && old) old.remove()
}

function renderOfferSkeletons() {
  $('#offerGrid').innerHTML = Array.from({ length:3 }, () => '<article class="offer-card"><div class="offer-image" style="animation:pulse 1.5s infinite"></div><div class="offer-body"><div style="height:12px;background:#f2ece9;border-radius:8px;width:40%"></div><div style="height:23px;background:#f2ece9;border-radius:8px;width:75%;margin:13px 0"></div><div style="height:35px;background:#f2ece9;border-radius:8px"></div></div></article>').join('')
}

function renderOffers() {
  const grid = $('#offerGrid')
  const list = offers.filter(o => activeCategory === 'all' || o.category === activeCategory)
  $('#offersEmpty').classList.toggle('hidden', list.length > 0)
  grid.classList.toggle('hidden', list.length === 0)
  $('#demoNote').classList.toggle('hidden', !list.some(o => o.is_demo))

  grid.innerHTML = list.map(offer => {
    const saving = offer.regular_price > 0 ? Math.round((1 - offer.junta_price / offer.regular_price) * 100) : 0
    const progress = pct(offer.waitlist_count, offer.queue_target)
    const favored = favorites.has(offer.id)
    return `<article class="offer-card" data-offer-id="${offer.id}">
      <div class="offer-image">
        ${offer.image_url ? `<img src="${esc(offer.image_url)}" alt="${esc(offer.title)}" loading="lazy">` : ''}
        <div class="offer-badges"><span class="offer-badge ${offer.is_demo ? 'demo' : ''}">${offer.is_demo ? 'DEMONSTRAÇÃO' : 'SEXTA • 18H'}</span><button class="favorite-btn ${favored ? 'on' : ''}" data-favorite="${offer.id}" aria-label="Favoritar">${favored ? '♥' : '♡'}</button></div>
      </div>
      <div class="offer-body">
        <div class="offer-merchant"><b>${esc(offer.business_name)} ${offer.verified ? '✓' : ''}</b><span>${esc(offer.city)} • ${esc(offer.state)}</span></div>
        <h3>${esc(offer.title)}</h3>
        <div class="offer-prices"><s>${money(offer.regular_price)}</s><strong>${money(offer.junta_price)}</strong><span class="offer-save">-${saving}%</span></div>
        <div class="queue-block">
          <div class="queue-top"><b>${offer.waitlist_count} pessoas na fila</b><span>meta de fila ${offer.queue_target}</span></div>
          <div class="queue-progress"><i style="width:${progress}%"></i></div>
          <div class="queue-top"><span>Mínimo econômico: ${offer.min_paid}</span><span>${progress}%</span></div>
        </div>
        <div class="offer-footer"><button class="card-action primary" data-join="${offer.id}" ${offer.status === 'sold_out' ? 'disabled' : ''}>${offerActionLabel(offer)}</button><button class="card-action secondary" data-details="${offer.id}">Detalhes</button></div>
      </div>
    </article>`
  }).join('')

  $$('[data-details]').forEach(btn => btn.addEventListener('click', () => showOffer(btn.dataset.details)))
  $$('[data-join]').forEach(btn => btn.addEventListener('click', () => toggleWaitlist(btn.dataset.join)))
  $$('[data-favorite]').forEach(btn => btn.addEventListener('click', e => { e.stopPropagation(); toggleFavorite(btn.dataset.favorite) }))
}

function showOffer(id) {
  const offer = offers.find(o => o.id === id)
  if (!offer) return
  activeOfferId = id
  const saving = offer.regular_price > 0 ? Math.round((1 - offer.junta_price / offer.regular_price) * 100) : 0
  const progress = pct(offer.waitlist_count, offer.queue_target)
  $('#offerModalContent').innerHTML = `<div class="offer-detail-grid">
    <div class="offer-detail-image">${offer.image_url ? `<img src="${esc(offer.image_url)}" alt="${esc(offer.title)}">` : ''}</div>
    <div class="offer-detail-copy">
      <div class="merchant-line"><span class="merchant-avatar">${esc((offer.business_name || 'J')[0])}</span><div><b>${esc(offer.business_name)}</b><small>${esc(offer.city)} • ${esc(offer.state)}</small></div>${offer.verified ? '<span class="verified">✓</span>' : ''}</div>
      <span class="eyebrow">${offer.is_demo ? 'OFERTA DEMONSTRATIVA' : 'COMPRA COLETIVA'}</span>
      <h2 id="offerModalTitle">${esc(offer.title)}</h2>
      <p class="detail-description">${esc(offer.description)}</p>
      <div class="detail-pricing"><s>${money(offer.regular_price)}</s><strong>${money(offer.junta_price)}</strong><span class="offer-save">economize ${saving}%</span></div>
      <div class="detail-box">
        <div class="detail-box-row"><b>Fila agora</b><strong>${offer.waitlist_count} pessoas</strong></div>
        <div class="queue-progress"><i style="width:${progress}%"></i></div>
        <div class="detail-box-row"><span>Mínimo que viabiliza</span><b>${offer.min_paid} pagamentos</b></div>
        <div class="detail-box-row"><span>Unidades disponíveis</span><b>${offer.max_units}</b></div>
        <div class="detail-box-row"><span>Fila de segurança</span><b>${offer.queue_target}</b></div>
        <div class="detail-box-row"><span>Abre</span><b>${dateTime(offer.opens_at)}</b></div>
      </div>
      <button class="primary-btn wide" id="detailJoin">${offerActionLabel(offer)}</button>
      <button class="text-btn wide" id="shareOffer">Compartilhar esta oferta ↗</button>
    </div>
  </div>`
  $('#detailJoin').addEventListener('click', () => toggleWaitlist(id))
  $('#shareOffer').addEventListener('click', () => shareOffer(offer))
  openModal('offerModal')
}

async function toggleWaitlist(id, forceJoin = false) {
  const offer = offers.find(o => o.id === id)
  if (!offer) return
  if (!currentUser) {
    pendingJoinId = id
    openModal('authModal')
    return
  }
  if (offer.status === 'open' && !waitlist.has(id)) {
    toast('O checkout seguro será conectado na próxima etapa da V1')
    return
  }

  if (waitlist.has(id) && !forceJoin) {
    const { error } = await supabase.from('offer_waitlist').delete().eq('offer_id', id).eq('user_id', currentUser.id)
    if (error) return toast('Não foi possível sair da fila')
    waitlist.delete(id)
    toast('Você saiu da fila')
  } else if (!waitlist.has(id)) {
    const { error } = await supabase.from('offer_waitlist').insert({ offer_id:id, user_id:currentUser.id })
    if (error && error.code !== '23505') return toast('Não foi possível entrar na fila')
    waitlist.add(id)
    toast('Lugar guardado. Você não pagou nada ainda.')
  }

  await loadOffers()
  renderOffers()
  renderAccount()
  if (!$('#offerModal').classList.contains('hidden')) showOffer(id)
}

async function toggleFavorite(id) {
  if (!currentUser) return openModal('authModal')
  if (favorites.has(id)) {
    const { error } = await supabase.from('favorite_offers').delete().eq('offer_id', id).eq('user_id', currentUser.id)
    if (error) return toast('Não foi possível remover')
    favorites.delete(id)
  } else {
    const { error } = await supabase.from('favorite_offers').insert({ offer_id:id, user_id:currentUser.id })
    if (error && error.code !== '23505') return toast('Não foi possível favoritar')
    favorites.add(id)
  }
  renderOffers(); renderAccount()
}

async function shareOffer(offer) {
  const text = `${offer.title} por ${money(offer.junta_price)} no Junta. Quanto mais gente entra, maior a compra coletiva.`
  try {
    if (navigator.share) await navigator.share({ title:`${offer.title} • Junta`, text, url:location.origin })
    else { await navigator.clipboard.writeText(`${text} ${location.origin}`); toast('Link copiado') }
  } catch (_) {}
}

async function login(e) {
  e.preventDefault()
  const form = new FormData(e.currentTarget)
  const btn = e.currentTarget.querySelector('button[type=submit]')
  btn.disabled = true; btn.textContent = 'Entrando...'
  const { error } = await supabase.auth.signInWithPassword({ email:form.get('email'), password:form.get('password') })
  btn.disabled = false; btn.textContent = 'Entrar'
  if (error) return toast('E-mail ou senha incorretos')
  closeModal('authModal')
  toast('Bem-vindo ao Junta')
}

async function signup(e) {
  e.preventDefault()
  const form = new FormData(e.currentTarget)
  const btn = e.currentTarget.querySelector('button[type=submit]')
  btn.disabled = true; btn.textContent = 'Criando...'
  const { data, error } = await supabase.auth.signUp({
    email:form.get('email'), password:form.get('password'),
    options:{ data:{ display_name:form.get('display_name') } }
  })
  btn.disabled = false; btn.textContent = 'Criar minha conta'
  if (error) return toast(error.message.includes('registered') ? 'Esse e-mail já está cadastrado' : 'Não foi possível criar a conta')
  e.currentTarget.reset()
  if (data.session) { closeModal('authModal'); toast('Conta criada. Bem-vindo ao Junta!') }
  else toast('Conta criada. Confira seu e-mail para confirmar o acesso.')
}

function renderAccount() {
  if (!currentUser) return
  $('#accountWelcome').textContent = `${profile?.display_name || currentUser.email} • ${roleLabel(profile?.role)}`
  const queueOffers = offers.filter(o => waitlist.has(o.id))
  const favoriteOffers = offers.filter(o => favorites.has(o.id))
  $('#myQueues').innerHTML = queueOffers.length ? queueOffers.map(dashOfferRow).join('') : blank('Você ainda não entrou em nenhuma fila.', 'Escolha uma oferta e toque em “Entrar na fila”.')
  $('#myFavorites').innerHTML = favoriteOffers.length ? favoriteOffers.map(dashOfferRow).join('') : blank('Nenhum favorito ainda.', 'Use o coração nas ofertas que você quer acompanhar.')
  $('#myOrders').innerHTML = orders.length ? orders.map(orderRow).join('') : blank('Nenhuma compra concluída.', 'Quando o checkout estiver conectado, seus vouchers aparecerão aqui.')
  $$('[data-dash-offer]').forEach(btn => btn.addEventListener('click', () => { showView('home'); setTimeout(() => showOffer(btn.dataset.dashOffer), 50) }))
}

function dashOfferRow(o) {
  return `<article class="dash-row"><img src="${esc(o.image_url || '')}" alt=""><div class="dash-row-main"><b>${esc(o.title)}</b><small>${esc(o.business_name)} • abre ${dateTime(o.opens_at)}</small></div><div class="dash-row-price"><b>${money(o.junta_price)}</b><button class="tiny-btn" data-dash-offer="${o.id}">Abrir</button></div></article>`
}
function orderRow(o) { return `<article class="dash-row"><div class="dash-row-main"><b>Pedido ${esc(o.voucher_code)}</b><small>${statusLabel(o.order_status)} • ${dateTime(o.created_at)}</small></div><div class="dash-row-price"><b>${money(o.total_amount)}</b></div></article>` }
function blank(title, copy) { return `<div class="blank-state"><b>${esc(title)}</b><p>${esc(copy)}</p></div>` }

function renderSeller() {
  $('#sellerLoggedOut').classList.toggle('hidden', !!currentUser)
  $('#sellerNoBusiness').classList.toggle('hidden', !currentUser || !!business)
  $('#sellerDashboard').classList.toggle('hidden', !currentUser || !business)
  if (!business) return

  $('#businessName').textContent = business.name
  $('#businessStatus').textContent = statusLabel(business.status)
  $('#businessStatus').classList.toggle('approved', business.status === 'approved')
  const feedRows = offers.filter(o => o.business_id === business.id)
  const queue = feedRows.reduce((sum, o) => sum + Number(o.waitlist_count || 0), 0)
  const live = sellerOffers.filter(o => ['scheduled','open'].includes(o.status)).length
  const pending = sellerOffers.filter(o => o.status === 'pending').length
  const maxVolume = sellerOffers.reduce((sum, o) => sum + Number(o.max_units || 0), 0)
  $('#sellerMetrics').innerHTML = [
    ['PESSOAS NA FILA', queue, 'interesse acumulado'],
    ['OFERTAS ATIVAS', live, 'aprovadas/agendadas'],
    ['EM ANÁLISE', pending, 'aguardando Junta'],
    ['CAPACIDADE', maxVolume, 'unidades nas ofertas']
  ].map(([l,v,e]) => `<article class="metric-card"><small>${l}</small><b>${v}</b><em>${e}</em></article>`).join('')

  $('#sellerOffers').innerHTML = sellerOffers.length ? sellerOffers.map(o => {
    const feed = feedRows.find(x => x.id === o.id)
    return `<div class="seller-offer-row"><div><b>${esc(o.title)}</b><small>${statusLabel(o.status)}</small></div><b>${money(o.junta_price)}</b><small>${feed?.waitlist_count || 0} na fila</small><small>${o.max_units} un.</small></div>`
  }).join('') : blank('Nenhuma oferta criada.', 'Crie a primeira oferta para começar a formar demanda.')
}

async function createBusiness(e) {
  e.preventDefault()
  if (!currentUser) return openModal('authModal')
  const fd = new FormData(e.currentTarget)
  const name = String(fd.get('name') || '').trim()
  const slug = `${slugify(name)}-${Date.now().toString(36).slice(-5)}`
  const btn = e.currentTarget.querySelector('button[type=submit]')
  btn.disabled = true; btn.textContent = 'Enviando...'
  const { error } = await supabase.from('businesses').insert({
    owner_id:currentUser.id, name, slug, category:fd.get('category'), description:fd.get('description') || '', whatsapp:fd.get('whatsapp') || '', city:fd.get('city'), state:String(fd.get('state')).toUpperCase(), address_line:fd.get('address_line'), status:'pending', verified:false
  })
  btn.disabled = false; btn.textContent = 'Enviar cadastro para análise'
  if (error) return toast('Não foi possível cadastrar a empresa')
  closeModal('businessModal'); e.currentTarget.reset(); toast('Empresa enviada para análise')
  await Promise.all([loadOffers(), loadUserState()]); renderAll(); showView('seller')
}

async function createOffer(e) {
  e.preventDefault()
  if (!currentUser || !business) return
  const fd = new FormData(e.currentTarget)
  const regular = Number(fd.get('regular_price'))
  const junta = Number(fd.get('junta_price'))
  const min = Number(fd.get('min_paid'))
  const max = Number(fd.get('max_units'))
  const queue = Number(fd.get('queue_target'))
  if (junta > regular) return toast('O preço Junta precisa ser menor ou igual ao preço normal')
  if (max < min || queue < max) return toast('Use: mínimo ≤ máximo ≤ fila de segurança')

  const btn = e.currentTarget.querySelector('button[type=submit]')
  btn.disabled = true; btn.textContent = 'Enviando oferta...'
  let imageUrl = null
  const file = fd.get('image')
  if (file && file.size) {
    if (file.size > 5 * 1024 * 1024) { btn.disabled=false; btn.textContent='Enviar oferta para aprovação'; return toast('A foto deve ter no máximo 5 MB') }
    const ext = ({'image/jpeg':'jpg','image/png':'png','image/webp':'webp'})[file.type]
    if (!ext) { btn.disabled=false; btn.textContent='Enviar oferta para aprovação'; return toast('Use JPG, PNG ou WebP') }
    const path = `${currentUser.id}/${crypto.randomUUID()}.${ext}`
    const upload = await supabase.storage.from('offer-images').upload(path, file, { contentType:file.type, upsert:false })
    if (upload.error) { btn.disabled=false; btn.textContent='Enviar oferta para aprovação'; return toast('Não foi possível enviar a foto') }
    imageUrl = supabase.storage.from('offer-images').getPublicUrl(path).data.publicUrl
  }

  const payload = {
    business_id:business.id, created_by:currentUser.id, title:fd.get('title'), description:fd.get('description') || '', category:fd.get('category'), image_url:imageUrl,
    regular_price:regular, junta_price:junta, min_paid:min, max_units:max, queue_target:queue,
    opens_at:new Date(fd.get('opens_at')).toISOString(), closes_at:new Date(fd.get('closes_at')).toISOString(),
    pickup_start:fd.get('pickup_start') ? new Date(fd.get('pickup_start')).toISOString() : null,
    pickup_end:fd.get('pickup_end') ? new Date(fd.get('pickup_end')).toISOString() : null,
    repeat_weekly:fd.get('repeat_weekly') === 'on', status:'pending', featured:false, is_demo:false, demo_seed_count:0
  }
  const { error } = await supabase.from('offers').insert(payload)
  btn.disabled = false; btn.textContent = 'Enviar oferta para aprovação'
  if (error) { console.error(error); return toast('Não foi possível criar a oferta') }
  closeModal('newOfferModal'); e.currentTarget.reset(); toast('Oferta enviada para aprovação')
  await Promise.all([loadOffers(), loadUserState()]); renderAll(); showView('seller')
}

function slugify(value) { return String(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'').slice(0,50) || 'empresa' }

function fillOfferDateDefaults() {
  const start = nextFridayAt18()
  const close = new Date(start.getTime() + 2 * 60 * 60 * 1000)
  const pickup = new Date(start.getTime() + 2.25 * 60 * 60 * 1000)
  const pickupEnd = new Date(start.getTime() + 5 * 60 * 60 * 1000)
  const localInput = d => { const z = new Date(d.getTime() - d.getTimezoneOffset()*60000); return z.toISOString().slice(0,16) }
  $('#offerForm [name=opens_at]').value = localInput(start)
  $('#offerForm [name=closes_at]').value = localInput(close)
  $('#offerForm [name=pickup_start]').value = localInput(pickup)
  $('#offerForm [name=pickup_end]').value = localInput(pickupEnd)
}

async function loadAdmin() {
  if (profile?.role !== 'admin') return
  const [businessesRes, offersRes, allBusinesses, allOffers] = await Promise.all([
    supabase.from('businesses').select('*').eq('status','pending').order('created_at'),
    supabase.from('offers').select('*,businesses(name)').eq('status','pending').order('created_at'),
    supabase.from('businesses').select('id,status', { count:'exact' }),
    supabase.from('offers').select('id,status', { count:'exact' })
  ])
  const pendingBusinesses = businessesRes.data || []
  const pendingOffers = offersRes.data || []
  $('#pendingBusinessCount').textContent = pendingBusinesses.length
  $('#pendingOfferCount').textContent = pendingOffers.length
  $('#adminKpis').innerHTML = [
    ['EMPRESAS', allBusinesses.count || 0],['OFERTAS', allOffers.count || 0],['EMPRESAS PENDENTES', pendingBusinesses.length],['OFERTAS PENDENTES', pendingOffers.length]
  ].map(([l,v]) => `<article class="metric-card"><small>${l}</small><b>${v}</b></article>`).join('')
  $('#pendingBusinesses').innerHTML = pendingBusinesses.length ? pendingBusinesses.map(b => `<div class="admin-row"><div><b>${esc(b.name)}</b><small>${esc(b.city)} • ${esc(b.state)}</small></div><div class="admin-actions"><button class="tiny-btn approve" data-approve-business="${b.id}">Aprovar</button><button class="tiny-btn" data-suspend-business="${b.id}">Recusar</button></div></div>`).join('') : blank('Tudo em dia.', 'Nenhuma empresa aguardando aprovação.')
  $('#pendingOffers').innerHTML = pendingOffers.length ? pendingOffers.map(o => `<div class="admin-row"><div><b>${esc(o.title)}</b><small>${esc(o.businesses?.name || '')} • ${money(o.junta_price)}</small></div><div class="admin-actions"><button class="tiny-btn approve" data-approve-offer="${o.id}">Aprovar</button><button class="tiny-btn" data-cancel-offer="${o.id}">Recusar</button></div></div>`).join('') : blank('Tudo em dia.', 'Nenhuma oferta aguardando aprovação.')
  $$('[data-approve-business]').forEach(btn => btn.addEventListener('click', () => adminUpdateBusiness(btn.dataset.approveBusiness, 'approved', true)))
  $$('[data-suspend-business]').forEach(btn => btn.addEventListener('click', () => adminUpdateBusiness(btn.dataset.suspendBusiness, 'suspended', false)))
  $$('[data-approve-offer]').forEach(btn => btn.addEventListener('click', () => adminUpdateOffer(btn.dataset.approveOffer, 'scheduled')))
  $$('[data-cancel-offer]').forEach(btn => btn.addEventListener('click', () => adminUpdateOffer(btn.dataset.cancelOffer, 'cancelled')))
}

async function adminUpdateBusiness(id, status, verified) {
  const { error } = await supabase.from('businesses').update({ status, verified }).eq('id', id)
  if (error) return toast('Não foi possível atualizar a empresa')
  toast(status === 'approved' ? 'Empresa aprovada' : 'Empresa recusada')
  await loadAdmin(); await loadOffers(); renderOffers()
}
async function adminUpdateOffer(id, status) {
  const { error } = await supabase.from('offers').update({ status }).eq('id', id)
  if (error) return toast('Não foi possível atualizar a oferta')
  toast(status === 'scheduled' ? 'Oferta aprovada e agendada' : 'Oferta recusada')
  await loadAdmin(); await loadOffers(); renderOffers()
}

function nextFridayAt18() {
  const now = new Date()
  const target = new Date(now)
  let add = (5 - now.getDay() + 7) % 7
  target.setDate(now.getDate() + add)
  target.setHours(18,0,0,0)
  if (target <= now) target.setDate(target.getDate() + 7)
  return target
}

function startGlobalCountdown() {
  const tick = () => {
    const diff = Math.max(0, nextFridayAt18() - new Date())
    const h = Math.floor(diff / 3600000)
    const m = Math.floor((diff % 3600000) / 60000)
    const s = Math.floor((diff % 60000) / 1000)
    $('#globalCountdown').innerHTML = `<strong>${String(h).padStart(2,'0')}</strong><span>:</span><strong>${String(m).padStart(2,'0')}</strong><span>:</span><strong>${String(s).padStart(2,'0')}</strong>`
  }
  tick(); setInterval(tick, 1000)
}

init().catch(err => { console.error(err); toast('O Junta encontrou um erro ao iniciar') })

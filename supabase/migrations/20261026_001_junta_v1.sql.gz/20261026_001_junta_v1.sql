create extension if not exists pgcrypto;

-- Remove a estrutura antiga do iPerto.
drop table if exists public.favorites cascade;
drop table if exists public.listing_photos cascade;
drop table if exists public.listings cascade;
drop table if exists public.iphone_models cascade;
drop table if exists public.reports cascade;
drop table if exists public.profiles cascade;

-- O bucket antigo 'listing-images' fica sem uso; o Supabase bloqueia exclusão direta por SQL.

create schema if not exists private;
revoke all on schema private from public;
grant usage on schema private to authenticated;

create table public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  phone text,
  role text not null default 'buyer' check (role in ('buyer','seller','admin')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.businesses (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users(id) on delete set null,
  name text not null,
  slug text not null unique,
  category text not null default 'outros',
  description text not null default '',
  logo_url text,
  whatsapp text,
  city text not null default '',
  state text not null default '',
  address_line text not null default '',
  status text not null default 'pending' check (status in ('pending','approved','suspended')),
  verified boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.offers (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  created_by uuid references auth.users(id) on delete set null,
  title text not null,
  description text not null default '',
  category text not null default 'outros',
  image_url text,
  regular_price numeric(12,2) not null check (regular_price >= 0),
  junta_price numeric(12,2) not null check (junta_price >= 0 and junta_price <= regular_price),
  min_paid integer not null check (min_paid >= 1),
  max_units integer not null check (max_units >= min_paid),
  queue_target integer not null check (queue_target >= max_units),
  opens_at timestamptz not null,
  closes_at timestamptz not null,
  pickup_start timestamptz,
  pickup_end timestamptz,
  repeat_weekly boolean not null default false,
  status text not null default 'pending' check (status in ('draft','pending','scheduled','open','closed','cancelled','sold_out')),
  featured boolean not null default false,
  is_demo boolean not null default false,
  demo_seed_count integer not null default 0 check (demo_seed_count >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (closes_at > opens_at),
  check (pickup_end is null or pickup_start is null or pickup_end > pickup_start)
);

create table public.offer_stats (
  offer_id uuid primary key references public.offers(id) on delete cascade,
  waitlist_count integer not null default 0 check (waitlist_count >= 0),
  paid_count integer not null default 0 check (paid_count >= 0),
  redeemed_count integer not null default 0 check (redeemed_count >= 0),
  shares_count integer not null default 0 check (shares_count >= 0),
  updated_at timestamptz not null default now()
);

create table public.offer_waitlist (
  id uuid primary key default gen_random_uuid(),
  offer_id uuid not null references public.offers(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (offer_id, user_id)
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  offer_id uuid not null references public.offers(id) on delete restrict,
  user_id uuid not null references auth.users(id) on delete restrict,
  quantity integer not null default 1 check (quantity >= 1 and quantity <= 20),
  unit_price numeric(12,2) not null check (unit_price >= 0),
  total_amount numeric(12,2) generated always as (quantity * unit_price) stored,
  payment_status text not null default 'pending' check (payment_status in ('pending','approved','refunded','expired','failed')),
  order_status text not null default 'waiting_payment' check (order_status in ('waiting_payment','confirmed','redeemed','cancelled')),
  payment_provider text,
  provider_payment_id text,
  voucher_code text not null unique default upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10)),
  created_at timestamptz not null default now(),
  paid_at timestamptz,
  redeemed_at timestamptz
);

create table public.favorite_offers (
  user_id uuid not null references auth.users(id) on delete cascade,
  offer_id uuid not null references public.offers(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, offer_id)
);

create index businesses_owner_idx on public.businesses(owner_id);
create index businesses_status_idx on public.businesses(status);
create index offers_business_idx on public.offers(business_id);
create index offers_status_opens_idx on public.offers(status, opens_at);
create index waitlist_user_idx on public.offer_waitlist(user_id);
create index waitlist_offer_idx on public.offer_waitlist(offer_id);
create index orders_user_idx on public.orders(user_id);
create index orders_offer_idx on public.orders(offer_id);
create index favorite_offers_offer_idx on public.favorite_offers(offer_id);
create index offers_created_by_idx on public.offers(created_by);

create or replace function private.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles
    where user_id = (select auth.uid()) and role = 'admin'
  );
$$;

create or replace function private.owns_business(target_business uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.businesses
    where id = target_business and owner_id = (select auth.uid())
  );
$$;

create or replace function private.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles(user_id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', ''))
  on conflict (user_id) do nothing;
  return new;
end;
$$;

create or replace function private.touch_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create or replace function private.business_promotes_owner()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.owner_id is not null then
    update public.profiles
       set role = case when role = 'buyer' then 'seller' else role end,
           updated_at = now()
     where user_id = new.owner_id;
  end if;
  return new;
end;
$$;


create or replace function private.protect_business_system_fields()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select auth.uid()) is not null and not private.is_admin() then
    new.owner_id := old.owner_id;
    new.status := old.status;
    new.verified := old.verified;
  end if;
  return new;
end;
$$;

create or replace function private.protect_offer_system_fields()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select auth.uid()) is not null and not private.is_admin() then
    new.business_id := old.business_id;
    new.created_by := old.created_by;
    new.status := old.status;
    new.featured := old.featured;
    new.is_demo := old.is_demo;
    new.demo_seed_count := old.demo_seed_count;
  end if;
  return new;
end;
$$;

create or replace function private.create_offer_stats()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.offer_stats(offer_id) values (new.id)
  on conflict (offer_id) do nothing;
  return new;
end;
$$;

create or replace function private.sync_waitlist_stats()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare target_offer uuid;
begin
  target_offer := coalesce(new.offer_id, old.offer_id);
  update public.offer_stats
     set waitlist_count = (select count(*) from public.offer_waitlist where offer_id = target_offer),
         updated_at = now()
   where offer_id = target_offer;
  return coalesce(new, old);
end;
$$;

create or replace function private.sync_order_stats()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare target_offer uuid;
begin
  target_offer := coalesce(new.offer_id, old.offer_id);
  update public.offer_stats
     set paid_count = (select count(*) from public.orders where offer_id = target_offer and payment_status = 'approved'),
         redeemed_count = (select count(*) from public.orders where offer_id = target_offer and order_status = 'redeemed'),
         updated_at = now()
   where offer_id = target_offer;
  return coalesce(new, old);
end;
$$;

revoke all on function private.is_admin() from public;
revoke all on function private.owns_business(uuid) from public;
grant execute on function private.is_admin() to authenticated;
grant execute on function private.owns_business(uuid) to authenticated;

-- Garante perfil para contas existentes, caso o projeto seja reutilizado no futuro.
insert into public.profiles(user_id, display_name)
select id, coalesce(raw_user_meta_data ->> 'display_name', '')
from auth.users
on conflict (user_id) do nothing;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function private.handle_new_user();

create trigger profiles_touch before update on public.profiles
for each row execute function private.touch_updated_at();
create trigger businesses_protect before update on public.businesses
for each row execute function private.protect_business_system_fields();
create trigger businesses_touch before update on public.businesses
for each row execute function private.touch_updated_at();
create trigger offers_protect before update on public.offers
for each row execute function private.protect_offer_system_fields();
create trigger offers_touch before update on public.offers
for each row execute function private.touch_updated_at();
create trigger businesses_promote_owner after insert on public.businesses
for each row execute function private.business_promotes_owner();
create trigger offers_make_stats after insert on public.offers
for each row execute function private.create_offer_stats();
create trigger waitlist_stats_insert after insert on public.offer_waitlist
for each row execute function private.sync_waitlist_stats();
create trigger waitlist_stats_delete after delete on public.offer_waitlist
for each row execute function private.sync_waitlist_stats();
create trigger order_stats_insert after insert on public.orders
for each row execute function private.sync_order_stats();
create trigger order_stats_update after update on public.orders
for each row execute function private.sync_order_stats();
create trigger order_stats_delete after delete on public.orders
for each row execute function private.sync_order_stats();

alter table public.profiles enable row level security;
alter table public.businesses enable row level security;
alter table public.offers enable row level security;
alter table public.offer_stats enable row level security;
alter table public.offer_waitlist enable row level security;
alter table public.orders enable row level security;
alter table public.favorite_offers enable row level security;

revoke all on public.profiles, public.businesses, public.offers, public.offer_stats, public.offer_waitlist, public.orders, public.favorite_offers from anon, authenticated;
grant select on public.businesses, public.offers, public.offer_stats to anon, authenticated;
grant select on public.profiles to authenticated;
grant update(display_name, phone) on public.profiles to authenticated;
grant insert, update, delete on public.businesses, public.offers to authenticated;
grant select, insert, delete on public.offer_waitlist to authenticated;
grant select on public.orders to authenticated;
grant select, insert, delete on public.favorite_offers to authenticated;

create policy profiles_select_own_or_admin on public.profiles
for select to authenticated
using ((select auth.uid()) = user_id or private.is_admin());

create policy profiles_update_own on public.profiles
for update to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

create policy businesses_public_read on public.businesses
for select to anon, authenticated
using (status = 'approved' or owner_id = (select auth.uid()) or private.is_admin());

create policy businesses_insert_own on public.businesses
for insert to authenticated
with check (owner_id = (select auth.uid()) and status = 'pending' and verified = false);

create policy businesses_update_own on public.businesses
for update to authenticated
using (owner_id = (select auth.uid()) or private.is_admin())
with check (owner_id = (select auth.uid()) or private.is_admin());

create policy businesses_delete_own on public.businesses
for delete to authenticated
using (owner_id = (select auth.uid()) or private.is_admin());

create policy offers_public_read on public.offers
for select to anon, authenticated
using (
  (
    status in ('scheduled','open','closed','sold_out')
    and exists (select 1 from public.businesses b where b.id = business_id and b.status = 'approved')
  )
  or private.owns_business(business_id)
  or private.is_admin()
);

create policy offers_insert_owner on public.offers
for insert to authenticated
with check ((private.owns_business(business_id) and status in ('draft','pending') and featured = false and is_demo = false and demo_seed_count = 0) or private.is_admin());

create policy offers_update_owner on public.offers
for update to authenticated
using (private.owns_business(business_id) or private.is_admin())
with check (private.owns_business(business_id) or private.is_admin());

create policy offers_delete_owner on public.offers
for delete to authenticated
using (private.owns_business(business_id) or private.is_admin());

create policy offer_stats_public_read on public.offer_stats
for select to anon, authenticated
using (true);

create policy waitlist_select_own on public.offer_waitlist
for select to authenticated
using ((select auth.uid()) = user_id or private.is_admin());

create policy waitlist_insert_own on public.offer_waitlist
for insert to authenticated
with check ((select auth.uid()) = user_id);

create policy waitlist_delete_own on public.offer_waitlist
for delete to authenticated
using ((select auth.uid()) = user_id or private.is_admin());

create policy orders_select_related on public.orders
for select to authenticated
using (
  (select auth.uid()) = user_id
  or exists (
    select 1 from public.offers o
    where o.id = offer_id and private.owns_business(o.business_id)
  )
  or private.is_admin()
);

create policy favorites_select_own on public.favorite_offers
for select to authenticated
using ((select auth.uid()) = user_id);
create policy favorites_insert_own on public.favorite_offers
for insert to authenticated
with check ((select auth.uid()) = user_id);
create policy favorites_delete_own on public.favorite_offers
for delete to authenticated
using ((select auth.uid()) = user_id);

create or replace view public.offer_feed
with (security_invoker = true)
as
select
  o.id,
  o.business_id,
  b.name as business_name,
  b.slug as business_slug,
  b.logo_url,
  b.city,
  b.state,
  b.verified,
  o.title,
  o.description,
  o.category,
  o.image_url,
  o.regular_price,
  o.junta_price,
  o.min_paid,
  o.max_units,
  o.queue_target,
  o.opens_at,
  o.closes_at,
  o.pickup_start,
  o.pickup_end,
  o.repeat_weekly,
  o.status,
  o.featured,
  o.is_demo,
  (o.demo_seed_count + coalesce(s.waitlist_count, 0)) as waitlist_count,
  coalesce(s.paid_count, 0) as paid_count,
  coalesce(s.redeemed_count, 0) as redeemed_count,
  coalesce(s.shares_count, 0) as shares_count
from public.offers o
join public.businesses b on b.id = o.business_id
left join public.offer_stats s on s.offer_id = o.id;

grant select on public.offer_feed to anon, authenticated;

-- Imagens das ofertas: públicas para leitura, upload restrito ao próprio usuário.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('offer-images', 'offer-images', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = excluded.public, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

create policy offer_images_public_read on storage.objects
for select to anon, authenticated
using (bucket_id = 'offer-images');

create policy offer_images_insert_own on storage.objects
for insert to authenticated
with check (bucket_id = 'offer-images' and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy offer_images_update_own on storage.objects
for update to authenticated
using (bucket_id = 'offer-images' and owner_id = (select auth.uid())::text)
with check (bucket_id = 'offer-images' and owner_id = (select auth.uid())::text);

create policy offer_images_delete_own on storage.objects
for delete to authenticated
using (bucket_id = 'offer-images' and owner_id = (select auth.uid())::text);

-- Conteúdo demonstrativo da V1. Marcação is_demo evita confundir com oferta real.
insert into public.businesses (id, owner_id, name, slug, category, description, city, state, status, verified)
values
('11111111-1111-4111-8111-111111111111', null, 'Brasa Burger', 'brasa-burger', 'comida', 'Hambúrguer artesanal feito na chapa.', 'São Paulo', 'SP', 'approved', true),
('22222222-2222-4222-8222-222222222222', null, 'Açougue Central', 'acougue-central', 'mercado', 'Cortes selecionados para compras em grupo.', 'São Paulo', 'SP', 'approved', true),
('33333333-3333-4333-8333-333333333333', null, 'Donna Pizza', 'donna-pizza', 'comida', 'Pizza artesanal de longa fermentação.', 'São Paulo', 'SP', 'approved', true),
('44444444-4444-4444-8444-444444444444', null, 'Casa Limpa', 'casa-limpa', 'mercado', 'Itens de casa em lotes com preço melhor.', 'São Paulo', 'SP', 'approved', true),
('55555555-5555-4555-8555-555555555555', null, 'Pé Leve', 'pe-leve', 'moda', 'Calçados casuais e esportivos.', 'São Paulo', 'SP', 'approved', true);

insert into public.offers (id, business_id, title, description, category, image_url, regular_price, junta_price, min_paid, max_units, queue_target, opens_at, closes_at, pickup_start, pickup_end, repeat_weekly, status, featured, is_demo, demo_seed_count)
values
('a1111111-1111-4111-8111-111111111111','11111111-1111-4111-8111-111111111111','Combo Smash Duplo','2 smash burgers + fritas. Retirada no local depois da confirmação.','comida','https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=1200&q=85',42.00,27.90,15,30,38,'2026-10-30 18:00:00-03','2026-10-30 19:00:00-03','2026-10-30 19:15:00-03','2026-10-30 23:00:00-03',true,'scheduled',true,true,24),
('a2222222-2222-4222-8222-222222222222','22222222-2222-4222-8222-222222222222','Picanha 1 kg','Peça resfriada. Compra coletiva com retirada no sábado.','mercado','https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1200&q=85',79.90,54.90,20,50,65,'2026-10-30 18:00:00-03','2026-10-30 20:00:00-03','2026-10-31 09:00:00-03','2026-10-31 14:00:00-03',true,'scheduled',true,true,41),
('a3333333-3333-4333-8333-333333333333','33333333-3333-4333-8333-333333333333','Pizza grande especial','Escolha entre sabores selecionados na retirada.','comida','https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=1200&q=85',69.00,39.90,18,40,50,'2026-10-30 18:00:00-03','2026-10-30 19:30:00-03','2026-10-30 19:30:00-03','2026-10-30 23:30:00-03',true,'scheduled',false,true,31),
('a4444444-4444-4444-8444-444444444444','44444444-4444-4444-8444-444444444444','Kit casa: 24 rolos','Pacote econômico para dividir preço de atacado sem comprar caixa fechada sozinho.','mercado','https://images.unsplash.com/photo-1583258292688-d0213dc5a3a8?auto=format&fit=crop&w=1200&q=85',39.90,24.90,30,80,100,'2026-10-30 18:00:00-03','2026-10-30 21:00:00-03','2026-10-31 09:00:00-03','2026-10-31 18:00:00-03',true,'scheduled',false,true,58),
('a5555555-5555-4555-8555-555555555555','55555555-5555-4555-8555-555555555555','Tênis casual urbano','Lote coletivo em numerações selecionadas.','moda','https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=1200&q=85',249.00,169.00,15,35,45,'2026-10-30 18:00:00-03','2026-10-30 21:30:00-03','2026-10-31 10:00:00-03','2026-10-31 17:00:00-03',true,'scheduled',false,true,21);

